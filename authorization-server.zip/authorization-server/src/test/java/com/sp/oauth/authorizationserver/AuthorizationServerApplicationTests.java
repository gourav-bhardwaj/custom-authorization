package com.sp.oauth.authorizationserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorizationServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
