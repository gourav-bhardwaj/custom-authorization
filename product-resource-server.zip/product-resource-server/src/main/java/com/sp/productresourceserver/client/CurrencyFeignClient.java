package com.sp.productresourceserver.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Component
@FeignClient(name="currency-exchange", configuration = FeignClientConfiguration.class)
public interface CurrencyFeignClient {
	
    @GetMapping("/currency-exchange/from/{from}/to/{to}")
	public CurrencyExchangeDto currencyExchange(@PathVariable(name = "from") String from, @PathVariable(name = "to") String to);

}
