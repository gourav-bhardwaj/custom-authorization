package com.sp.productresourceserver;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.core.convert.converter.Converter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.util.CollectionUtils;

public class KeycloakJwtConverter implements Converter<Jwt, Collection<GrantedAuthority>> {

	@Override
	public Collection<GrantedAuthority> convert(Jwt source) {
		Map<String, ArrayList<String>> realmAccess = source.getClaim("realm_access");

		if (CollectionUtils.isEmpty(realmAccess)) {
			return Collections.emptyList();
		}
		return realmAccess.get("roles").stream().peek(System.out::println).map(role -> "ROLE_".concat(role)).map(SimpleGrantedAuthority::new)
				.collect(Collectors.toList());
	}

}
