package com.sp.productresourceserver;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import feign.FeignException;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	
	@ExceptionHandler(FeignException.class)
	public ErrorDto feignClientExceptionHandler(FeignException exception, WebRequest request) {
		String requestURI = ((ServletWebRequest)request).getRequest().getRequestURI();
		HttpStatus status = HttpStatus.valueOf(exception.status());
		return new ErrorDto(LocalDateTime.now(), exception.getMessage(), status.getReasonPhrase(), status.value(), requestURI);
	}

}
