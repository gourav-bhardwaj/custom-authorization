package com.sp.productresourceserver.client;

import lombok.Data;

@Data
public class CurrencyExchangeDto {

	private int id;
	private String from;
	private String to;
	private Double convertionMultiply;
	private String environment;
	
}
