package com.sp.productresourceserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients
@SpringBootApplication
public class ProductResourceServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductResourceServerApplication.class, args);
	}

}
