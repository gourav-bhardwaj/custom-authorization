package com.sp.productresourceserver.client;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpHeaders;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import feign.RequestInterceptor;
import feign.RequestTemplate;

public class FeignClientRequestInterceptor implements RequestInterceptor {

	@Override
	public void apply(RequestTemplate template) {
		Optional<HttpServletRequest> request = servletRequest();
		if (request.isPresent()) {
			HttpServletRequest httpServletRequest = request.get();
			String authorizationToken = httpServletRequest.getHeader(HttpHeaders.AUTHORIZATION).split(" ")[1];
			template.header(HttpHeaders.AUTHORIZATION, "Bearer " + authorizationToken);
		}
	}
	
	
	private Optional<HttpServletRequest> servletRequest() {
		return Optional.ofNullable(RequestContextHolder.getRequestAttributes())
				.filter(obj -> ServletRequestAttributes.class.isAssignableFrom(obj.getClass()))
				.map(ServletRequestAttributes.class::cast).map(requestAttributes -> requestAttributes.getRequest());
	}

}
