package com.sp.productresourceserver.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sp.productresourceserver.bean.UserRest;
import com.sp.productresourceserver.client.CurrencyExchangeDto;
import com.sp.productresourceserver.client.CurrencyFeignClient;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private CurrencyFeignClient feignClient;

	@GetMapping("/users/status")
	public ResponseEntity<String> userStatus() {
		SecurityContextHolder.getContext().getAuthentication().getAuthorities().forEach(authority -> {
			log.info("ROLE: {}", authority.getAuthority());
		});
		return ResponseEntity.ok("Working user....");
	}
	
	@PreAuthorize("hasAuthority('ROLE_user')")
	@GetMapping("/users/delete/{uid}")
	public ResponseEntity<String> deleteUser(@PathVariable Integer uid) {
		return ResponseEntity.ok("Delete user id: %d".formatted(uid));
	}
	
	@PostAuthorize("returnObject.userId == #jwt.subject")
	@GetMapping("/users/{uid}")
	public UserRest fetchUserId(@PathVariable String uid, @AuthenticationPrincipal Jwt jwt) {
		log.info("Fetch user id: {}", uid);
		return new UserRest(uid, "Gourav", "Kumar");
	}
	
	@GetMapping("/currency-exchange/from/{from}/to/{to}")
	public CurrencyExchangeDto currencyExchangeDto(@PathVariable String from, @PathVariable String to) {
		return feignClient.currencyExchange(from, to);
	}
}
