package com.sp.productresourceserver;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.oauth2.server.resource.OAuth2ResourceServerConfigurer;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;

@EnableGlobalMethodSecurity(securedEnabled = true, prePostEnabled = true)
@EnableWebSecurity
@Configuration
public class CustomWebSecurity {
	
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//Part - 1: Create JwtAuthenticationConverter instance.
//		JwtAuthenticationConverter jwtAuthenticationConverter = new JwtAuthenticationConverter();
//		jwtAuthenticationConverter.setJwtGrantedAuthoritiesConverter(new KeycloakJwtConverter());
		http.authorizeHttpRequests()
		.antMatchers(HttpMethod.GET, "/users/status").hasAuthority("SCOPE_email")
		.antMatchers("/actuator/**").permitAll()
		.anyRequest().authenticated().and()
/* OAuth2ResourceServerConfigurer.jwt(..) by default consider SCOPEs as role 
 * but if what to use some ROLEs in GrantAuthority then you should use custom approach.*/
		.oauth2ResourceServer(OAuth2ResourceServerConfigurer::jwt);
//Part - 2: If you to do some customization like: fetching authorities and implementing logging.
//		.oauth2ResourceServer().jwt().jwtAuthenticationConverter(jwtAuthenticationConverter);
		return http.build();
	}

}
