package com.sp.spgovtechapigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.oauth2.client.oidc.web.server.logout.OidcClientInitiatedServerLogoutSuccessHandler;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.security.web.server.SecurityWebFilterChain;

@SpringBootApplication
public class SpGovtechApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpGovtechApiGatewayApplication.class, args);
	}
	
	@Bean
	public SecurityWebFilterChain securityWebFilterChain(ServerHttpSecurity http, ReactiveClientRegistrationRepository repository) {
		http.authorizeExchange().pathMatchers("/actuator/**").permitAll()
		.and().authorizeExchange().anyExchange().authenticated()
		.and().oauth2Login().and().csrf().disable()
		.logout((logout) -> logout.logoutSuccessHandler(new OidcClientInitiatedServerLogoutSuccessHandler(repository)));
		return http.build();
	}
	
}
