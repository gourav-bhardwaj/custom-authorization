package com.sp.spgovtechapigateway;

import java.util.concurrent.TimeUnit;

import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.stereotype.Component;

import reactor.core.publisher.Mono;

@Component
public class ErrorGlobalFilter extends AbstractGatewayFilterFactory<ErrorGlobalFilter.Config> {
	
	public ErrorGlobalFilter() {
		super(Config.class);
	}

	public ErrorGlobalFilter(Class<Config> configClass) {
		super(configClass);
		// TODO Auto-generated constructor stub
	}

	@Override
	public GatewayFilter apply(Config config) {
		return (exchange, chain) -> {
			//int i = 5/0;
			System.out.println("Pre-Filter");
			return chain.filter(exchange).then(Mono.fromRunnable(() -> {
				//Post-Filter
				try {
					TimeUnit.SECONDS.sleep(5);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("Post-Filter");
			}));
		};
	}
	
	public static class Config {
		//Added the configuration properties
	}
	
}